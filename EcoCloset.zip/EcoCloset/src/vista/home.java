package vista;

import java.awt.Image;
import java.io.File;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import modelo.Publicacion;
import modelo.SqlUsuarios;

/**
 *
 * @author merch
 */
public class home extends javax.swing.JFrame {

    SqlUsuarios sqlUsuarios = new SqlUsuarios();
    int usuarioId= 1;

    public home() {

        initComponents();

    }

    private void cargarPublicaciones(int limit, int offset) {
        // Llamamos al método obtenerPublicaciones para cargar las publicaciones
        List<Publicacion> publicaciones = sqlUsuarios.obtenerPublicaciones(limit, offset);

        // Crear un nuevo panel para mostrar las publicaciones
        JPanel panelPublicaciones = new JPanel();
        panelPublicaciones.setLayout(new BoxLayout(panelPublicaciones, BoxLayout.Y_AXIS));  // Ajustar la disposición vertical

        // Verificar si hay publicaciones
        if (publicaciones.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay publicaciones disponibles.");
        }

        // Recorrer las publicaciones y agregarlas al panel
        for (Publicacion p : publicaciones) {
            // Agregar la descripción de la publicación
            JLabel labelDescripcion = new JLabel(p.getDescripcion());
            panelPublicaciones.add(labelDescripcion);

            // Verificar que la ruta de la imagen esté correcta
            System.out.println("Cargando imagen: " + p.getRutaImagen());

            // Agregar la imagen de la publicación
            ImageIcon imagen = new ImageIcon(p.getRutaImagen());
            Image img = imagen.getImage().getScaledInstance(128, 128, Image.SCALE_SMOOTH);  // Escalar la imagen
            JLabel labelImagen = new JLabel(new ImageIcon(img));
            panelPublicaciones.add(labelImagen);
        }

        // Actualizar el jPanel1 con las nuevas publicaciones
        jPanel1.removeAll();  // Eliminar cualquier componente anterior
        jPanel1.add(panelPublicaciones);  // Añadir el nuevo panel con las publicaciones
        jPanel1.revalidate();  // Validar el panel
        jPanel1.repaint();  // Redibujar el panel
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonCargarImg = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        buttonCargarPublicaciones = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        buttonCargarImg.setText("Carcar imagen");
        buttonCargarImg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonCargarImgActionPerformed(evt);
            }
        });
        getContentPane().add(buttonCargarImg, new org.netbeans.lib.awtextra.AbsoluteConstraints(241, 24, 121, -1));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 387, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 438, Short.MAX_VALUE)
        );

        jScrollPane1.setViewportView(jPanel1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 60, 390, -1));

        buttonCargarPublicaciones.setText("Cargar mas publicaciones");
        buttonCargarPublicaciones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonCargarPublicacionesActionPerformed(evt);
            }
        });
        getContentPane().add(buttonCargarPublicaciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 520, 270, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void buttonCargarImgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonCargarImgActionPerformed
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            System.out.println("Archivo seleccionado: " + selectedFile.getAbsolutePath());
            String descripcion = JOptionPane.showInputDialog("Ingrese una descripción para la publicación:");
            System.out.println("Usuario ID en sesión: " + usuarioId);

            try {
                if (descripcion != null && sqlUsuarios.guardarPublicacion(usuarioId, selectedFile, descripcion)) {
                    JOptionPane.showMessageDialog(this, "Publicación guardada exitosamente.");
                    cargarPublicaciones(5, 0);  // Volver a cargar las publicaciones después de guardar
                } else {
                    JOptionPane.showMessageDialog(this, "Error al guardar la publicación.");
                }
            } catch (SQLException ex) {
                Logger.getLogger(home.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_buttonCargarImgActionPerformed

    private void buttonCargarPublicacionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonCargarPublicacionesActionPerformed
        int limit = 1;  // Número de publicaciones por carga
        int offset = jPanel1.getComponentCount();  // El número de publicaciones ya cargadas (desplazamiento)
        cargarPublicaciones(limit, offset);  // Cargar más publicaciones


    }//GEN-LAST:event_buttonCargarPublicacionesActionPerformed

    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new home().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton buttonCargarImg;
    private javax.swing.JButton buttonCargarPublicaciones;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
