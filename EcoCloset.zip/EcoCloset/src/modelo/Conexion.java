
package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    // URL de la base de datos con la zona horaria configurada
    private static final String URL = "";
    private static final String USER = "";         
    private static final String PASSWORD = "";  

    // Método para obtener la conexión
    public static Connection getConnection() {
        try {
            // Carga del driver de MySQL (no siempre es necesario, pero es una buena práctica)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establece la conexión
            Connection con = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conexión exitosa a la base de datos app_ecocloset");
            return con;
        } catch (ClassNotFoundException e) {
            System.out.println("Error: Driver no encontrado");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
}

