package modelo;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author merch
 */
public class SqlUsuarios extends Conexion {

    public boolean registrar(usuarios usr) {
        PreparedStatement ps = null;
        Connection con = getConnection();

        if (usr.getNombre().isEmpty() || usr.getApellido().isEmpty()
                || usr.getCorreo().isEmpty() || usr.getTelefono().isEmpty()
                || usr.getContrasena().isEmpty()) {
            return false; // Retorna false si algún campo está vacío
        }
        if (!esEmail(usr.getCorreo())) {
            return false; // Retorna false si el formato del correo no es válido
        }

        String sql = "INSERT INTO  usuarios (nombre, apellido, correo,telefono,contrasena)VALUES (?,?,?,?,?)";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, usr.getNombre());
            ps.setString(2, usr.getApellido());
            ps.setString(3, usr.getCorreo());
            ps.setString(4, usr.getTelefono());
            ps.setString(5, usr.getContrasena());
            int resultado = ps.executeUpdate();
            return resultado > 0;
        } catch (SQLException ex) {
            Logger.getLogger(SqlUsuarios.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                Logger.getLogger(SqlUsuarios.class.getName()).log(Level.SEVERE, null, e);
            }
        }
    }

    public boolean login(usuarios usr) {
        String sql = "SELECT id, correo, contrasena, nombre FROM usuarios WHERE correo = ?";

        try (Connection con = Conexion.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, usr.getCorreo());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    if (usr.getContrasena().equals(rs.getString(3))) {
                        usr.setId(rs.getInt(1));
                        usr.setNombre(rs.getString(4));

                        return true;
                    } else {
                        return false;
                    }
                }
                return false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(SqlUsuarios.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public int existeUsuario(String usuario) {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = getConnection();

        String sql = "SELECT COUNT(id) FROM usuarios WHERE correo = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, usuario);
            rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt(1);
            }
            return 1;
        } catch (SQLException ex) {
            Logger.getLogger(SqlUsuarios.class.getName()).log(Level.SEVERE, null, ex);
            return 1;
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                Logger.getLogger(SqlUsuarios.class.getName()).log(Level.SEVERE, null, e);
            }
        }
    }

    public boolean esEmail(String correo) {
        Pattern pattern = Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");

        Matcher mather = pattern.matcher(correo);
        return mather.find();
    }

    public boolean guardarPublicacion(int usuarioId, File archivo, String descripcion) throws SQLException {
        try {
            // Generamos un nombre único para el archivo
            String nombreArchivo = UUID.randomUUID().toString() + "_" + archivo.getName();
            Path destino = Paths.get("", nombreArchivo); // aqui iria la carpeta o la raiz a la que quiero que se guarde las fotos que se suban

            // Copiamos el archivo a la nueva ubicación
            Files.copy(archivo.toPath(), destino);

            // Insertar en la base de datos la nueva publicación
            String rutaImagen = destino.toString();
            String sql = "INSERT INTO publicaciones (usuario_id, descripcion, ruta_imagen) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = Conexion.getConnection().prepareStatement(sql)) {
                stmt.setInt(1, usuarioId);
                stmt.setString(2, descripcion);
                stmt.setString(3, rutaImagen);
                int filasAfectadas = stmt.executeUpdate();
                return filasAfectadas > 0;
            }
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Publicacion> obtenerPublicaciones(int limit, int offset) {
        List<Publicacion> publicaciones = new ArrayList<>();
        String sql = "SELECT p.id, p.ruta_imagen, p.descripcion, u.nombre FROM publicaciones p "
                + "JOIN usuarios u ON p.usuario_id = u.id ORDER BY p.fecha_publicacion DESC LIMIT ? OFFSET ?";
        System.out.println("Ejecutando SQL: " + sql + " con limit=" + limit + " y offset=" + offset);

        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            if (limit <= 0 || offset < 0) {
                throw new IllegalArgumentException("El valor de limit o offset no es válido.");
            }

            ps.setInt(1, limit);
            ps.setInt(2, offset);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Publicacion pub = new Publicacion(
                        rs.getInt("id"),
                        rs.getString("ruta_imagen"),
                        rs.getString("descripcion"),
                        rs.getString("nombre")
                );
                publicaciones.add(pub);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SqlUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        }
        return publicaciones;
    }
}
