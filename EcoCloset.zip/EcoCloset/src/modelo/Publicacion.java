package modelo;

/**
 *
 * @author merch
 */
public class Publicacion {

    private int id;
    private String rutaImagen;
    private String descripcion;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRutaImagen() {
        return rutaImagen;
    }

    public void setRutaImagen(String rutaImagen) {
        this.rutaImagen = rutaImagen;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }
    private String nombreUsuario;

    public Publicacion(int id, String rutaImagen, String descripcion, String nombreUsuario) {
        this.id = id;
        this.rutaImagen = rutaImagen;
        this.descripcion = descripcion;
        this.nombreUsuario = nombreUsuario;
    }

}
